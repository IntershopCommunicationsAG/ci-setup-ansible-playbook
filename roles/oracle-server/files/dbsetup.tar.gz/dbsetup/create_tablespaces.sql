--
-- create_tablespaces.sql
--

SET ECHO OFF
SET LINESIZE 500
SET PAGESIZE 100
SET TRIMSPOOL ON

SPOOL ../log/create_tablespaces.log

DEFINE _dba                 = &1
DEFINE _dba_pw              = &2
DEFINE _connect_identifier  = &3
DEFINE _ts_temp             = &4
DEFINE _ts_user             = &5
DEFINE _ts_indx             = &6
DEFINE _ts_indx_ctx         = &7
DEFINE _ts_size             = &8

DEFINE _uni_size            = '2M'
DEFINE _sys_ts              = 'SYSTEM'

PROMPT CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba
       CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba

PROMPT
PROMPT Determine the file system path for the system tablespace and
PROMPT create the Intershop tablespace files within this location.
PROMPT

SET HEAD OFF FEEDBACK OFF TERM OFF
COL system_ts_path NEW_VALUE path

SELECT regexp_substr(df.name, '^(.*)[\\/]') AS system_ts_path
  FROM v$tablespace ts
  JOIN v$datafile df ON (df.ts#=ts.ts#)
 WHERE UPPER(ts.name) = '&_sys_ts';

SET HEAD ON FEEDBACK ON TERM ON

PROMPT
PROMPT The file system path for system tablespace is: &&path
PROMPT

PROMPT
PROMPT ********** Create Tablespace &_ts_temp *****************
PROMPT

CREATE TEMPORARY TABLESPACE &_ts_temp TEMPFILE '&path.&_ts_temp._01.dbf'
  SIZE &_ts_size AUTOEXTEND ON NEXT &_ts_size MAXSIZE UNLIMITED
  EXTENT MANAGEMENT LOCAL UNIFORM SIZE &_uni_size;

PROMPT
PROMPT ********** Create Tablespace &_ts_user *****************
PROMPT

CREATE TABLESPACE &_ts_user DATAFILE '&path.&_ts_user._01.dbf'
  SIZE &_ts_size AUTOEXTEND ON NEXT &_ts_size MAXSIZE UNLIMITED
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

PROMPT
PROMPT ********** Create Tablespace &_ts_indx *****************
PROMPT

CREATE TABLESPACE &_ts_indx DATAFILE '&path.&_ts_indx._01.dbf'
  SIZE &_ts_size AUTOEXTEND ON NEXT &_ts_size MAXSIZE UNLIMITED
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

PROMPT
PROMPT ********** Create Tablespace &_ts_indx_ctx *************
PROMPT

CREATE TABLESPACE &_ts_indx_ctx DATAFILE '&path.&_ts_indx_ctx._01.dbf'
  SIZE &_ts_size AUTOEXTEND ON NEXT &_ts_size MAXSIZE UNLIMITED
  EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO;

PROMPT
PROMPT Check all settings
PROMPT

COL FILE_NAME FORMAT A100

SELECT ts.name tablespace_name, bytes, creation_time, df.name file_name
  FROM gv$tablespace ts
  JOIN gv$datafile df ON (df.ts#=ts.ts#)
 WHERE ts.name IN ('&_ts_user','&_ts_indx','&_ts_indx_ctx')
UNION
SELECT ts.name tablespace_name, bytes, creation_time, tf.name file_name
  FROM gv$tablespace ts
  JOIN gv$tempfile tf ON (tf.ts#=ts.ts#)
 WHERE ts.name IN ('&_ts_temp')
 ORDER BY tablespace_name
/

SPOOL OFF
