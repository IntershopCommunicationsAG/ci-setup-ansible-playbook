--
-- configure_instance.sql
--

SET ECHO OFF
SET LINESIZE 500
SET PAGESIZE 100
SET TRIMSPOOL ON

SPOOL ../log/configure_instance.log

DEFINE _dba                 = &1
DEFINE _dba_pw              = &2
DEFINE _connect_identifier  = &3
DEFINE _appserver           = &4
DEFINE _processes           = &5
DEFINE _add_processes       = &6
DEFINE _open_cursors        = &7

DEFINE _ctx                 = 'ctxsys'
DEFINE _ctx_pw              = 'ctxsys'


PROMPT CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba
       CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba

PROMPT
PROMPT 1.1) Unlock the CTXSYS user
PROMPT

ALTER USER &_ctx ACCOUNT UNLOCK;
ALTER USER &_ctx IDENTIFIED BY &_ctx_pw;

PROMPT
PROMPT 1.2) Grants (EXECUTE ON ctx_ddl) with Grant Option from ctxsys user to sys and system
PROMPT

PROMPT CONNECT &_ctx/&_ctx_pw.@&_connect_identifier
       CONNECT &_ctx/&_ctx_pw.@&_connect_identifier

GRANT EXECUTE ON ctx_ddl TO    sys WITH GRANT OPTION;
GRANT EXECUTE ON ctx_ddl TO system WITH GRANT OPTION;

PROMPT CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba
       CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba

PROMPT
PROMPT 1.3) Lock the CTXSYS user again
PROMPT

ALTER USER &_ctx ACCOUNT LOCK;

SET HEAD OFF FEEDBACK OFF TERM OFF

COL procs_sum NEW_VALUE procs_sum
SELECT TO_CHAR((&_appserver*&_processes)+&_add_processes) AS procs_sum FROM dual;

SET HEAD ON FEEDBACK ON TERM ON

PROMPT
PROMPT 1.4) Increase Oracle open_cursors and processes
PROMPT
PROMPT   #AppServer       = &_appserver
PROMPT   Sum Processes    = (&_appserver*&_processes)+&_add_processes = &procs_sum (minimum required 150 for each Intershop AppServer instance)
PROMPT   set processes    = &procs_sum
PROMPT   set open_cursors = &_open_cursors (minimum required 500)
PROMPT

ALTER SYSTEM SET open_cursors = &_open_cursors scope = both;
ALTER SYSTEM SET processes = &procs_sum scope = spfile;

PROMPT
PROMPT 1.5) Set default password security profile parameters to unlimited (since 11gR2)
PROMPT
PROMPT   ALTER PROFILE default LIMIT failed_login_attempts UNLIMITED
PROMPT   ALTER PROFILE default LIMIT   password_grace_time UNLIMITED
PROMPT   ALTER PROFILE default LIMIT    password_life_time UNLIMITED
PROMPT   ALTER PROFILE default LIMIT    password_lock_time UNLIMITED
PROMPT

ALTER PROFILE default LIMIT failed_login_attempts UNLIMITED;
ALTER PROFILE default LIMIT   password_grace_time UNLIMITED;
ALTER PROFILE default LIMIT    password_life_time UNLIMITED;
ALTER PROFILE default LIMIT    password_lock_time UNLIMITED;

PROMPT
PROMPT 1.6) Disable password case sensitivity
PROMPT
PROMPT   set sec_case_sensitive_logon = false
PROMPT

ALTER SYSTEM SET sec_case_sensitive_logon = false scope = both;

PROMPT
PROMPT Check all settings
PROMPT

COL NAME            FORMAT A30
COL VALUE           FORMAT A30
COL PROFILE         FORMAT A10
COL RESOURCE_NAME   FORMAT A25
COL RESOURCE        FORMAT A25
COL LIMIT           FORMAT A25
COL SID             FORMAT A15

SELECT inst_id, name, value, ismodified
  FROM gv$parameter
 WHERE LOWER(name) IN ('open_cursors','processes','sec_case_sensitive_logon')
 ORDER BY name
/

SELECT inst_id, sid, name, value
  FROM gv$spparameter
 WHERE LOWER(name) IN ('open_cursors','processes','sec_case_sensitive_logon')
 ORDER BY name
/

SELECT *
  FROM dba_profiles
 WHERE profile = 'DEFAULT'
   AND LOWER(resource_name) IN ('failed_login_attempts','password_grace_time','password_life_time','password_lock_time')
 ORDER BY resource_name
/

SPOOL OFF
