--
-- create_user.sql
--

SET ECHO OFF
SET LINESIZE 500
SET PAGESIZE 100
SET TRIMSPOOL ON

SPOOL ../log/create_user.log

DEFINE _dba                 = &1
DEFINE _dba_pw              = &2
DEFINE _connect_identifier  = &3
DEFINE _us                  = &4
DEFINE _pw                  = &5
DEFINE _ts_temp             = &6
DEFINE _ts_user             = &7

PROMPT CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba
       CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba

PROMPT
PROMPT Create Intershop User: &_us
PROMPT

CREATE USER &_us
  IDENTIFIED BY &_pw
  DEFAULT TABLESPACE &_ts_user
  TEMPORARY TABLESPACE &_ts_temp
  PROFILE DEFAULT ACCOUNT UNLOCK;

ALTER USER &_us DEFAULT ROLE ALL;

PROMPT
PROMPT Grant all necessary Privileges
PROMPT CONNECT, RESOURCE, CTXAPP, UNLIMITED TABLESPACE
PROMPT to Intershop User: &_us
PROMPT

GRANT CONNECT               TO &_us;
GRANT RESOURCE              TO &_us;
GRANT CTXAPP                TO &_us;
GRANT UNLIMITED TABLESPACE  TO &_us;

PROMPT
PROMPT Grant CONNECT-Privileges directly
PROMPT

GRANT CREATE CLUSTER        TO &_us;
GRANT CREATE DATABASE LINK  TO &_us;
GRANT CREATE SEQUENCE       TO &_us;
GRANT CREATE SYNONYM        TO &_us;
GRANT CREATE TABLE          TO &_us;
GRANT CREATE VIEW           TO &_us;

PROMPT
PROMPT Grant RESOURCE-Privileges directly
PROMPT

GRANT CREATE PROCEDURE      TO &_us;
GRANT CREATE TRIGGER        TO &_us;
GRANT CREATE TYPE           TO &_us;

PROMPT
PROMPT Grant the CREATE SNAPSHOT privilege
PROMPT

GRANT CREATE SNAPSHOT       TO &_us;

PROMPT
PROMPT Grant CTXAPP-Privileges directly
PROMPT

GRANT EXECUTE ON CTX_DDL    TO &_us;

PROMPT
PROMPT Grant ANALYZE ANY
PROMPT

GRANT ANALYZE ANY           TO &_us;

PROMPT
PROMPT Grant DBMS_STREAMS_ADM to enable/suppress Streams via set_tag
PROMPT Only used within multi data center environments.
PROMPT

GRANT EXECUTE ON DBMS_STREAMS_ADM TO &_us;

PROMPT
PROMPT Check all settings
PROMPT

SELECT username, account_status, default_tablespace, temporary_tablespace, created, profile
  FROM dba_users
 WHERE UPPER(username) = UPPER('&_us')
/

SELECT *
  FROM dba_role_privs
 WHERE UPPER(grantee) = UPPER('&_us')
ORDER BY granted_role
/

SELECT *
  FROM dba_sys_privs
 WHERE UPPER(grantee) = UPPER('&_us')
ORDER BY privilege
/

SELECT *
  FROM dba_tab_privs
 WHERE UPPER(grantee) = UPPER('&_us')
ORDER BY owner,table_name
/

SPOOL OFF
