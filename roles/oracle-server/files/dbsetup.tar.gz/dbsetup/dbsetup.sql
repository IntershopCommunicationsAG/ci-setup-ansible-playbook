--
-- dbsetup.sql
--

SPOOL ../log/dbsetup.log

DEFINE _dba                = 'SYS'
DEFINE _dba_pw             = 'intershop'
DEFINE _connect_identifier = '//localhost:1521/isdb1'
DEFINE _sqlp               = 'sqlplus /nolog'

DEFINE _appserver          = '1'
DEFINE _processes          = '150'
DEFINE _add_processes      = '30'
DEFINE _open_cursors       = '500'

DEFINE _ts_temp            = 'IS_TEMP'
DEFINE _ts_user            = 'IS_USERS'
DEFINE _ts_indx            = 'IS_INDX'
DEFINE _ts_indx_ctx        = 'IS_INDX_CTX'

DEFINE _ts_size            = '100M'

DEFINE _us                 = 'intershop'
DEFINE _pw                 = 'intershop'

CONNECT &_dba/&_dba_pw.@&_connect_identifier AS sysdba

SET HEAD ON FEEDBACK ON TERM ON

@configure_instance.sql &_dba &_dba_pw &_connect_identifier &_appserver &_processes &_add_processes &_open_cursors
@create_tablespaces.sql &_dba &_dba_pw &_connect_identifier &_ts_temp &_ts_user &_ts_indx &_ts_indx_ctx &_ts_size
@create_user.sql &_dba &_dba_pw &_connect_identifier &_us &_pw &_ts_temp &_ts_user
DISCONNECT

EXIT

