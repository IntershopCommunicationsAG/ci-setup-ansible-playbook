--
-- restart_instance.sql
--

SET ECHO OFF
SET LINESIZE 500
SET PAGESIZE 100
SET TRIMSPOOL ON


SPOOL ../log/restart_instance.log

DEFINE _dba                 = &1
DEFINE _dba_pw              = &2

--
-- CONNECT &_dba/&_dba_pw AS sysdba
--

PROMPT
PROMPT
PROMPT A Database instance re-start is necessary. Make a local
PROMPT "CONNECT &_dba AS sysdba" with SQL*Plus and type:
PROMPT
PROMPT SHUTDOWN IMMEDIATE
PROMPT STARTUP
PROMPT
PROMPT or re-start the database instance within the installation on
PROMPT
PROMPT * Windows as Administrator with:
PROMPT
PROMPT   ** XE database
PROMPT     NET STOP  OracleServiceXE
PROMPT     NET START OracleServiceXE
PROMPT
PROMPT   ** other <SID> database
PROMPT     NET STOP  OracleService<SID>
PROMPT     NET START OracleService<SID>
PROMPT
PROMPT * Linux as root with:
PROMPT
PROMPT   ** XE database
PROMPT     /etc/init.d/oracle-xe stop
PROMPT     /etc/init.d/oracle-xe start
PROMPT
PROMPT   ** other <SID> database
PROMPT     /etc/init.d/oracle stop
PROMPT     /etc/init.d/oracle start
PROMPT

SPOOL OFF


